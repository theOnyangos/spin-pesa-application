$(".menu-opener").click(function(){
  $(".menu-opener, .menu-opener-inner,.more-less,.menu-opener-inner1, .menu").toggleClass("active");
});